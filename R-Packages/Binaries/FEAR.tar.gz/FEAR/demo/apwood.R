print("perform outlier analysis on Wood (1973) data as in Wilson (1993)")
data(fswood)
attach(fswood)
x=matrix(nrow=5,ncol=82)
x[1,]=x1
x[2,]=x2
x[3,]=x3
x[4,]=x4
x[5,]=x5
y=matrix(y1,nrow=1,ncol=82)
#
# perform outlier analysis on Wood (1973) data as in Wilson (1993):
clock1=proc.time()
date1=date()
aa=ap(X=x,Y=y,NDEL=12)
#
# report time used:
clock2=proc.time()
date2=date()
dclock=clock2-clock1
print(paste("started ",date1,sep=""),quote=FALSE)
print(paste("   user time  =",dclock[1],sep=""),quote=FALSE)
print(paste("   system time=",dclock[2],sep=""),quote=FALSE)
print(paste("   wall time  =",dclock[3],sep=""),quote=FALSE)
print(paste("ended   ",date2,sep=""),quote=FALSE)
#
# print results:
print(aa$r0)
print(aa$imat)
#
# produce the log-ratio plot as in Wilson (1993):
ap.plot(aa$ratio)

